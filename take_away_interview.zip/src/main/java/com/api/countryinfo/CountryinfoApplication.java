package com.api.countryinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountryinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountryinfoApplication.class, args);
	}

}
